<?php

global $lang;

$lang['en_US']['EditableFormField']['DEFAULT'] = 'Default';
$lang['en_US']['EditableFormField']['EXTRACLASS'] = 'Extra Class';